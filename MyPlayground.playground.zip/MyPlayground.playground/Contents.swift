//: Playground - noun: a place where people can play

import UIKit

var year = 1999
var message = "Hello, World"

let birthYear = 1980
let welcomeMessage = "안녕하세요"
